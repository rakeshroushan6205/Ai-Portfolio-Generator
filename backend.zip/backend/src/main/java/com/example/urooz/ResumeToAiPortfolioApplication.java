package com.example.urooz;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ResumeToAiPortfolioApplication {

	public static void main(String[] args) {
		SpringApplication.run(ResumeToAiPortfolioApplication.class, args);
	}

}
